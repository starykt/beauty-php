<!DOCTYPE html>
<html lang="en">
<?php
  include 'head.php';
?>
<body class="wave">
  <?php
    include "header.php";
  ?>
  <div class="imagem">
    <img class="imagemCabelo" src="cabelo.png" alt="Bem vindo">
    <img class="imagemLogo" src="logo.png" alt="Bem vindo">
  </div>

</body>
</html>
