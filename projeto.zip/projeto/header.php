<?php
session_start();

if($_SESSION["idAtendente"] == null) {
    header("Location: index.php");
}

?>
<section>
    <nav>
      <ul class="menuItems">
        <li><a href='home.php'>Home</a></li>
        <li><a href='client.php'>Clientes</a></li>
            <?php
            if($_SESSION['cargo'] == 'adm') {
            ?>
            <li><a href='#'>Atendentes</a></li>

            <?php
            }
        ?>
        <li><a href='#'>Agendamentos</a></li>
        <li><a href='#'>Notas</a></li>
        <li><a href='#'>Catálogos</a></li>
        <li><a href='#'>Serviços</a></li>
        <li><a href='logout.php'>Sair</a></li>
      </ul>
    </nav>
  </section>