<?php
require_once('connection.php');
$consulta = $connection->query("SELECT idCliente, nome, cpf, endereco, telefone FROM cliente;");
?>
<!DOCTYPE html> 
  <html> 
    <head> 
      <meta charset="UTF-8"> 
      <title>Tutorial</title> 
    </head> 
    <?php
        include "head.php";
    ?>
    <body class="wave" style=" width: 100%;
        height: 100%;">
    <?php
        include "header.php";
    ?>
      <table border="1" style="margin:auto;"> 
        <tr> 
          <td>Nome</td> 
          <td>CPF</td>
          <td>Endereço</td>
          <td>Telefone</td>
          <td> Ação</td>
        </tr> 
        <?php while ($linha = $consulta->fetch(PDO::FETCH_ASSOC)) { ?> 
        <tr> 
          <td><?php echo $linha['nome']; ?></td> 
          <td><?php echo $linha['cpf']; ?></td> 
          <td><?php echo $linha['endereco']; ?></td> 
          <td><?php echo $linha['telefone']; ?></td> 
          <td>
          <a href="editClient.php?idCliente=<?php echo $linha['idCliente']; ?>">
            <button type="button" class="btn btn-primary">Editar</button></a>
          <a href="deleteClient.php?idCliente=<?php echo $linha['idCliente']; ?>">
            <button type="button" class="btn btn-danger">Excluir</button></a>
          </td>
        </tr> 
        <?php } ?> 
      </table> 
    </body> 
</html>